# IsraelCraft Chess

A framework-free chess widget designed to live at `/public/games/chess/`. It keeps styles scoped under `.ic-chess` / `ic-chess-*` and exposes `window.ICChess` plus ES-module exports.

## Embed

Copy this into the page template where the game should appear:

```html
<div id="ic-chess-root"></div>
<script type="module" src="/games/chess/chess.js"></script>
```

The module imports `chess.js` 1.4.0 from jsDelivr at first initialization. This avoids a build step, but does require network access. To self-host it, place the matching `chess.js` ES module in `vendor/chess.js` and change `CHESS_MODULE` at the top of `chess.js` to `./vendor/chess.js`.

## Host API

```html
<div id="ic-chess-root"></div>
<script type="module">
  import '/games/chess/chess.js';
  await window.ICChess.init({
    root: '#ic-chess-root',
    mode: 'local', // 'local' | 'bot' | 'online'
    serverUrl: 'ws://localhost:8787',
    clock: false,
    timeControl: { minutes: 5, increment: 0 },
    themeVars: { accent: '#5bc0be' }
  });
  window.ICChess.on('gameEnd', result => console.log('Game ended', result));
  console.log(window.ICChess.exportFEN());
  // window.ICChess.loadFEN('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  // window.ICChess.destroy();
</script>
```

`init({root, mode, serverUrl, clock, timeControl})` returns the instance; instance methods include `on`, `destroy`, `loadFen`, and `saveFen`. Static API: `ICChess.init`, `ICChess.on`, `ICChess.exportFEN`, `ICChess.loadFEN`, `ICChess.destroy`. Theme can be customized by setting CSS custom properties on the root, such as `--icc-bg`, `--icc-panel`, `--icc-text`, `--icc-muted`, `--icc-accent`, `--icc-light`, and `--icc-dark`. Existing site variables are used as fallbacks where possible; confirm names against the host site's stylesheet before release.

## Optional online server

```sh
cd public/games/chess/server-example
npm install
node node-chess-server.js
```

Then configure `serverUrl: 'ws://localhost:8787'` (use `wss://` behind HTTPS in production). One player chooses **Create room**, then the other enters the displayed room code and chooses **Join**. The server validates each move with chess.js and broadcasts its authoritative FEN. It also demonstrates heartbeat pings and basic disconnected-slot recovery.

### Protocol sketch

Client messages: `create_room`, `join {roomId}`, `resume {roomId}`, `move {from,to,promotion?}`, `new_game`, `chat {text}`, `ping`.

Server messages: `room_created {roomId}`, `sync {roomId,fen,turn,color}`, `move {from,to,promotion?,san,fen,turn}`, `chat {text,from}`, `error {message}`. The server intentionally ignores client-provided SAN/FEN as authority and derives move state itself.

## Tests

After installing the server-example dependencies:

```sh
node ../tests/rules.test.cjs
```

## Known limitations / next steps

- The easy bot is random legal play; hard mode uses a small depth-limited minimax search, not Stockfish and not a calibrated Elo level.
- No Stockfish WASM binary is bundled. Add and test a licensed Stockfish distribution separately if stronger play is needed.
- Clock UI is scaffolded; set the clock selector in the interface for controls. For tournament-grade clocks, persist authoritative clock timestamps on the server.
- The online sample is a demonstration, not production infrastructure: room state is memory-only, reconnection is basic, and there is no authentication, matchmaking, persistence, abuse control, or origin allow-list. Add these before public deployment.
- Chat is rendered with `textContent` and length-limited. Use TLS (`wss://`) on public sites.
- PGN export is included; PGN import, spectator mode, share links, persistent ratings, animations and sound are not implemented.
- Keyboard access is supported through normal buttons and tab/enter/space navigation; richer arrow-key board navigation can be added.
- The repository's CSS and header/footer could not be inspected through the available repository access in this run, so the CSS uses neutral defaults and safe variable fallbacks. Review theme tokens and static paths against the actual site before merging.

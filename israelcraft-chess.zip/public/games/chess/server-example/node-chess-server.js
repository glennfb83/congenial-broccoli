'use strict';
// Demo server: validates all moves with chess.js. For production add persistence,
// authentication, origin allow-listing, rate limits and durable reconnect tokens.
const { WebSocketServer, WebSocket } = require('ws');
const { Chess } = require('chess.js');
const crypto = require('node:crypto');
const PORT = Number(process.env.PORT || 8787);
const wss = new WebSocketServer({ port: PORT, perMessageDeflate: false });
const rooms = new Map();
function send(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function roomId() { return crypto.randomBytes(3).toString('hex').toUpperCase(); }
function broadcast(room, data, except) { for (const p of room.players) if (p && p !== except) send(p, data); }
function detach(ws) { const room=rooms.get(ws.roomId); if(!room)return; const i=room.players.indexOf(ws); if(i>=0) room.players[i]=null; room.disconnectedAt=Date.now(); }
wss.on('connection', ws => {
  ws.isAlive=true; ws.on('pong',()=>ws.isAlive=true); ws.roomId=null; ws.playerColor=null;
  ws.on('message', raw => {
    let msg; try { if(raw.length>4096) throw new Error('Message too large'); msg=JSON.parse(raw.toString()); } catch { return send(ws,{type:'error',message:'Invalid message'}); }
    if(msg.type==='create_room'){
      let id; do{id=roomId()}while(rooms.has(id)); const room={id,game:new Chess(),players:[ws,null],disconnectedAt:null};rooms.set(id,room);ws.roomId=id;ws.playerColor='w';send(ws,{type:'room_created',roomId:id});send(ws,{type:'sync',roomId:id,fen:room.game.fen(),turn:room.game.turn(),color:'w'});return;
    }
    if(msg.type==='join'||msg.type==='resume'){
      const id=String(msg.roomId||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,12),room=rooms.get(id);if(!room)return send(ws,{type:'error',message:'Room not found'});
      let slot=room.players.indexOf(null);if(slot<0&&msg.type==='resume'&&ws.playerColor)slot=ws.playerColor==='w'?0:1;if(slot<0)return send(ws,{type:'error',message:'Room is full'});
      ws.roomId=id;ws.playerColor=slot===0?'w':'b';room.players[slot]=ws;room.disconnectedAt=null;send(ws,{type:'sync',roomId:id,fen:room.game.fen(),turn:room.game.turn(),color:ws.playerColor});broadcast(room,{type:'peer_joined'},ws);return;
    }
    const room=rooms.get(ws.roomId);if(!room)return send(ws,{type:'error',message:'Join a room first'});
    if(msg.type==='move'){
      if(ws.playerColor!==room.game.turn())return send(ws,{type:'error',message:'Not your turn'});
      if(!/^[a-h][1-8]$/.test(msg.from||'')||!/^[a-h][1-8]$/.test(msg.to||''))return send(ws,{type:'error',message:'Invalid square'});
      let move;try{move=room.game.move({from:msg.from,to:msg.to,...(['q','r','b','n'].includes(msg.promotion)?{promotion:msg.promotion}:{})});}catch{}
      if(!move)return send(ws,{type:'error',message:'Illegal move'});
      const event={type:'move',from:move.from,to:move.to,promotion:move.promotion, san:move.san,fen:room.game.fen(),turn:room.game.turn()};broadcast(room,event);send(ws,event);return;
    }
    if(msg.type==='new_game'){room.game=new Chess();broadcast(room,{type:'sync',roomId:room.id,fen:room.game.fen(),turn:'w',color:ws.playerColor});return;}
    if(msg.type==='chat'){const text=String(msg.text||'').replace(/[\u0000-\u001f\u007f]/g,'').slice(0,240);if(text)broadcast(room,{type:'chat',text,from:ws.playerColor},null);return;}
    if(msg.type==='ping')return send(ws,{type:'pong',at:Date.now()});
  });
  ws.on('close',()=>detach(ws));ws.on('error',()=>detach(ws));
});
const heartbeat=setInterval(()=>{for(const ws of wss.clients){if(!ws.isAlive){ws.terminate();continue;}ws.isAlive=false;ws.ping();}for(const [id,r] of rooms){if(r.players.every(p=>!p)&&r.disconnectedAt&&Date.now()-r.disconnectedAt>30*60*1000)rooms.delete(id);}},15000);
wss.on('close',()=>clearInterval(heartbeat));console.log(`IsraelCraft Chess WebSocket server listening on ws://localhost:${PORT}`);

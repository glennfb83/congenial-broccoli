// Run after npm install in server-example: node ../tests/rules.test.cjs
const assert=require('node:assert/strict');const {Chess}=require('chess.js');
const game=new Chess();assert.equal(game.fen(),'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
assert.equal(game.move({from:'e2',to:'e4'}).san,'e4');assert.equal(game.turn(),'b');
assert.throws(()=>game.move({from:'e7',to:'e4'}));
const roundTrip=new Chess(game.fen());assert.equal(roundTrip.fen(),game.fen());
assert.throws(()=>game.move({from:'e1',to:'e3'}));
const mate=new Chess();for(const m of ['f3','e5','g4','Qh4#'])mate.move(m);assert.equal(mate.isCheckmate(),true);
console.log('Chess rule tests passed');
